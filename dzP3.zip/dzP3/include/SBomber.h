#pragma once

#include <vector>

#include <iterator>

#include "LevelGUI.h"
#include "Plane.h"
#include "Bomb.h"
#include "Ground.h"
#include "Tank.h"

class SBomber
{
public:

    SBomber();
    ~SBomber();
    
    inline bool GetExitFlag() const { return exitFlag; }

    void ProcessKBHit();
    void TimeStart();
    void TimeFinish();

    void DrawFrame();
    void MoveObjects();
    void CheckObjects();

private:

    void CheckPlaneAndLevelGUI();
    void CheckBombsAndGround();
    void  CheckDestoyableObjects(Bomb* pBomb);

    void  DeleteDynamicObj(DynamicObject * pBomb);
    void  DeleteStaticObj(GameObject* pObj);

    Ground * FindGround() const;
    Plane * FindPlane() const;
    LevelGUI * FindLevelGUI() const;
    std::vector<DestroyableGroundObject*> FindDestoyableGroundObjects() const;
    std::vector<Bomb*> FindAllBombs() const;

    void DropBomb();

    std::vector<DynamicObject*> vecDynamicObj;
    std::vector<GameObject*> vecStaticObj;

    class BombIterator
    {
        std::vector<DynamicObject*>& ref;
        size_t curIndex;
        Bomb* pBomb;
    public:
        BombIterator(std::vector<DynamicObject*>& _ref) : ref(_ref),curIndex(-1), pBomb(nullptr) {};

        void reset() { curIndex=-1; pBomb=nullptr;};

        BombIterator& operator++() {
            ++curIndex;
            if (curIndex == -1)
                curIndex = 0;
            for(; curIndex < ref.size(); curIndex++)
            {
                pBomb = dynamic_cast<Bomb*>(ref[curIndex]);
                if (pBomb != nullptr) break;
            }

            if (curIndex == ref.size())
            {
                curIndex = -1;
                pBomb = nullptr;
            }

            return *this;
        }
        Bomb* operator*() {return pBomb;}

        bool operator==(BombIterator it) // проверка на лог. равенство итераторов
        {
            if (curIndex == it.curIndex &&
                pBomb == it.pBomb &&
                ref == it.ref)
            {
                return true;
            }
            return false;
        }

        bool operator!=(BombIterator it) // проверка на лог. неравенство
        {
            return !(*this == it);
        }
    };

    BombIterator begin() { BombIterator it(vecDynamicObj); return it; }
    BombIterator end() { BombIterator it(vecDynamicObj); it.reset(); return it; }

private:
    bool exitFlag;

    uint64_t startTime, finishTime, passedTime;
    uint16_t bombsNumber, deltaTime, fps;
    int16_t score;
};

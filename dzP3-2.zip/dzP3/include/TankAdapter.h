#ifndef TANKADAPTER_H
#define TANKADAPTER_H

#include "DestroyableGroundObject.h"
#include "TankAdaptee.h"

class TankAdapter: public DestroyableGroundObject {
public:
    TankAdapter( std::string p) : param(p)
    {
     tank=new TankAdaptee();
     int pos1=param.find(';');
     x=std::atof(param.substr(0,pos1).c_str());
     int pos2=param.rfind(';');
     y=std::atof(param.substr(pos1+1,pos2).c_str());
     this->SetPos(x,y);
     width=std::atoi(param.substr(pos2+1,param.size()).c_str());
     this->SetWidth(width);
    };

private:
    ~TankAdapter() {
      delete tank;
    };
    void SetPos(double nx, double ny) override;
    uint16_t GetWidth() const override;

    void Draw() const override;
    bool isInside(double x1, double x2) const override;

    inline uint16_t GetScore() const override {return tank->GetScore();};

    void SetWidth(uint16_t widthN) override;

    TankAdaptee* tank;
    std::string param;
};

#endif // TANKADAPTER_H
